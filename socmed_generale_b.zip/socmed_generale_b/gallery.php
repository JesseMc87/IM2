<title>Gallery</title>
<?php
include 'views/header.php';

echo "GALLERY";

include 'views/footer.php';
?>
