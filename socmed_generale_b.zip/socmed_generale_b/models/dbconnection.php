<?php

function create_connection(){
    $host="localhost";
    $username="root";
    $password="";
    $database="socmed_generale_b";
    
    return new mysqli($host, $username, $password, $database);
              
}