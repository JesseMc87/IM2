<title>Social Media</title>
<?php
include 'views/header.php';

echo "HOME";

include 'views/footer.php';
?>
