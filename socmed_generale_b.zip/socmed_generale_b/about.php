<title>About</title>
<?php
include 'views/header.php';

echo "ABOUT";

include 'views/footer.php';
?>
